f=imread("original_cameraman.jpg");
f1=rgb2gray(f);
d1=double(f1);
pr=d1(1,1);
pr_err=zeros(length(d1(:,1)),length(d1(1,:)));
for i=1:length(d1(:,1))
    for j=1:length(d1(1,:))
        pr_err(i,j)= (d1(i,j)-pr);
        pr= d1(i,j);
    end
end
pr_err1=zeros(length(d1(:,1)),length(d1(1,:)));
for i=1:length(pr_err(:,1))
    for j=1:length(pr_err(1,:))
        if(pr_err(i,j)<=0)
            pr_err1(i,j)=(127*(pr_err(i,j)+255))/255;
        else
            pr_err1(i,j)=pr_err(i,j);
        end
    end
end
c=uint8(pr_err1);
imshow(c);
d2=zeros(length(d1(:,1)),length(d1(1,:)));
d2(1,1)=pr;
for i=1:length(d1(:,1))
    for j=1:length(d1(1,:))
        d2(i,j)=d2(i,j)+pr_err(i,j);
    end
end
