# golomb-codec
A MATLAB implementation of Golomb Coder/Decoder
Download the functions and add them to the working directory of MATLAB in the 'Set Path' option and you are all set to get going with Golomb coding.
